import BuyerNavbar from "../../templates/BuyerNav";

const Buyer = (props) => {
    return (
        <div>
            <BuyerNavbar />
            <div className="container">
                <h1>Welcome to Home Page</h1>
            </div>
        </div>

    );
};

export default Buyer;
